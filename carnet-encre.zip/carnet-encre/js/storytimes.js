let histoiresDuFichier = [];
let histoires = [];

fetch("../data/stories.json")
  .then(response => {
    if (!response.ok) {
      throw new Error("Fichier JSON introuvable");
    }
    return response.json();
  })
  .then(data => {
    histoiresDuFichier = data.histoires;
    histoires = toutesLesHistoires(histoiresDuFichier);
    afficherHistoires();
  })
  .catch(error => {
    console.error("Problème avec le fichier JSON :", error);
    document.getElementById("liste-histoires").textContent =
      "Impossible de charger les histoires. Ouvre le site avec Live Server.";
  });

function afficherHistoires() {

  const recherche = document.getElementById("recherche").value.toLowerCase();

  const categorie = document.getElementById("filtre-categorie").value;
  const liste = document.getElementById("liste-histoires");

  liste.textContent = "";
  let nombre = 0;

  for (let i = 0; i < histoires.length; i++) {
    const histoire = histoires[i];

    const texte = (histoire.titre + " " + histoire.auteur).toLowerCase();
    const contientMot = texte.includes(recherche);

    const bonneCategorie = categorie == "toutes" || histoire.categorie == categorie;

    if (contientMot && bonneCategorie) {
      liste.appendChild(creerCarte(histoire, "histoire.html"));
      nombre++;
    }
  }

  document.getElementById("resultat").textContent = nombre + " histoire(s) trouvée(s)";
}

function publierHistoire() {
  const pseudo = document.getElementById("pseudo").value;
  const categorie = document.getElementById("categorie").value;
  const titre = document.getElementById("titre-histoire").value;
  const texte = document.getElementById("texte-histoire").value;
  const reglesAcceptees = document.getElementById("regles").checked;
  const message = document.getElementById("message-histoire");

  if (pseudo == "" || categorie == "" || titre == "") {
    message.textContent = "Veuillez remplir tous les champs !";
    return;
  }
  if (texte.length < 100) {
    message.textContent = "Ton histoire doit faire au moins 100 caractères (" + texte.length + " pour l'instant).";
    return;
  }
  if (reglesAcceptees == false) {
    message.textContent = "Tu dois cocher la case pour publier.";
    return;
  }

  const perso = lireHistoiresPerso();

  const nouvelleHistoire = {
    id: "perso" + (perso.length + 1),
    titre: titre,
    auteur: pseudo,
    categorie: categorie,
    date: new Date().toLocaleDateString(),
    likes: 0,
    resume: texte.slice(0, 100) + "…",
    texte: [texte]
  };

  perso.push(nouvelleHistoire);
  localStorage.setItem("histoiresPerso", JSON.stringify(perso));

  document.getElementById("pseudo").value = "";
  document.getElementById("categorie").value = "";
  document.getElementById("titre-histoire").value = "";
  document.getElementById("texte-histoire").value = "";
  document.getElementById("regles").checked = false;
  message.textContent = "Ton histoire est publiée 🎉";

  document.getElementById("recherche").value = "";
  document.getElementById("filtre-categorie").value = "toutes";
  histoires = toutesLesHistoires(histoiresDuFichier);
  afficherHistoires();
}
