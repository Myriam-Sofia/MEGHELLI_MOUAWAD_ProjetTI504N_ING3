const idChoisi = sessionStorage.getItem("histoireChoisie");
const zone = document.getElementById("lecture");

fetch("../data/stories.json")
  .then(response => {
    if (!response.ok) {
      throw new Error("Fichier JSON introuvable");
    }
    return response.json();
  })
  .then(data => {
    const histoires = toutesLesHistoires(data.histoires);

    let histoire = null;
    for (let i = 0; i < histoires.length; i++) {
      if (histoires[i].id == idChoisi) {
        histoire = histoires[i];
      }
    }

    zone.textContent = "";

    if (histoire == null) {
      const titre = document.createElement("h1");
      titre.textContent = "Histoire introuvable 😕";
      zone.appendChild(titre);
      return;
    }

    document.title = histoire.titre + " — Carnet d'Encre";

    const categorie = document.createElement("span");
    categorie.className = "categorie";
    categorie.textContent = CATEGORIES[histoire.categorie];

    const titre = document.createElement("h1");
    titre.textContent = histoire.titre;

    const auteur = document.createElement("p");
    auteur.className = "petit";
    auteur.textContent = "par " + histoire.auteur + " · " + histoire.date;

    zone.appendChild(categorie);
    zone.appendChild(titre);
    zone.appendChild(auteur);

    for (let i = 0; i < histoire.texte.length; i++) {
      const paragraphe = document.createElement("p");
      paragraphe.textContent = histoire.texte[i];
      zone.appendChild(paragraphe);
    }

    zone.appendChild(creerBoutonCoeur(histoire));
  })
  .catch(error => {
    console.error("Problème avec le fichier JSON :", error);
    zone.textContent = "Impossible de charger l'histoire. Ouvre le site avec Live Server.";
  });
