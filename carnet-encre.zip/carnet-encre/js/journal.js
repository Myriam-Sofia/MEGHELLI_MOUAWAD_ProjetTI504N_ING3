const HUMEURS = [
  { code: "joie", nom: "😊 Joyeux" },
  { code: "excite", nom: "🤩 Excité" },
  { code: "calme", nom: "😌 Calme" },
  { code: "fatigue", nom: "😴 Fatigué" },
  { code: "triste", nom: "😢 Triste" },
  { code: "colere", nom: "😡 En colère" }
];

function lirePages() {
  const texte = localStorage.getItem("journal");
  if (texte == null) {
    return [];
  }
  return JSON.parse(texte);
}

function sauverPages(pages) {
  localStorage.setItem("journal", JSON.stringify(pages));
}

function nomHumeur(code) {
  for (let i = 0; i < HUMEURS.length; i++) {
    if (HUMEURS[i].code == code) {
      return HUMEURS[i].nom;
    }
  }
  return "";
}

function enregistrerPage() {
  const date = document.getElementById("date").value;
  const titre = document.getElementById("titre").value;
  const texte = document.getElementById("texte").value;
  const message = document.getElementById("message-journal");

  let humeur = "";
  for (let i = 0; i < HUMEURS.length; i++) {
    if (document.getElementById("humeur-" + HUMEURS[i].code).checked) {
      humeur = HUMEURS[i].code;
    }
  }

  if (date == "" || titre == "" || texte == "") {
    message.textContent = "Veuillez remplir la date, le titre et le texte !";
    return;
  }

  const pages = lirePages();
  pages.push({ date: date, titre: titre, humeur: humeur, texte: texte });
  sauverPages(pages);

  document.getElementById("titre").value = "";
  document.getElementById("texte").value = "";
  message.textContent = "Page enregistrée ✍️";

  afficherPages();
  afficherStatistiques();
}

function afficherPages() {
  const recherche = document.getElementById("recherche").value.toLowerCase();
  const filtre = document.getElementById("filtre-humeur").value;
  const liste = document.getElementById("liste-pages");
  const pages = lirePages();

  liste.textContent = "";
  let nombre = 0;

  for (let i = pages.length - 1; i >= 0; i--) {
    const page = pages[i];

    const contientMot = page.titre.toLowerCase().includes(recherche) ||
                        page.texte.toLowerCase().includes(recherche);

    const bonneHumeur = filtre == "toutes" || page.humeur == filtre;

    if (contientMot && bonneHumeur) {
      liste.appendChild(creerPage(page, i));
      nombre++;
    }
  }

  if (nombre == 0) {
    const vide = document.createElement("p");
    vide.textContent = "Aucune page à afficher.";
    liste.appendChild(vide);
  }
}

function creerPage(page, numero) {
  const bloc = document.createElement("article");
  bloc.className = "page-journal";

  const titre = document.createElement("h3");
  titre.textContent = page.titre;

  const infos = document.createElement("p");
  infos.className = "petit";
  infos.textContent = page.date + " · " + nomHumeur(page.humeur);

  const texte = document.createElement("p");
  texte.textContent = page.texte;

  const boutonSupprimer = document.createElement("button");
  boutonSupprimer.type = "button";
  boutonSupprimer.className = "bouton bouton-clair";
  boutonSupprimer.textContent = "🗑️ Supprimer";
  boutonSupprimer.addEventListener("click", function () {
    supprimerPage(numero);
  });

  bloc.appendChild(titre);
  bloc.appendChild(infos);
  bloc.appendChild(texte);
  bloc.appendChild(boutonSupprimer);
  return bloc;
}

function supprimerPage(numero) {
  if (confirm("Supprimer définitivement cette page ?") == false) {
    return;
  }

  const pages = lirePages();
  const nouvellesPages = [];
  for (let i = 0; i < pages.length; i++) {
    if (i != numero) {
      nouvellesPages.push(pages[i]);
    }
  }
  sauverPages(nouvellesPages);
  afficherPages();
  afficherStatistiques();
}

function afficherStatistiques() {
  const pages = lirePages();
  const corps = document.getElementById("tableau-humeurs");
  corps.textContent = "";

  for (let i = 0; i < HUMEURS.length; i++) {

    let nombre = 0;
    for (let j = 0; j < pages.length; j++) {
      if (pages[j].humeur == HUMEURS[i].code) {
        nombre++;
      }
    }

    const ligne = document.createElement("tr");
    const caseHumeur = document.createElement("td");
    caseHumeur.textContent = HUMEURS[i].nom;
    const caseNombre = document.createElement("td");
    caseNombre.textContent = nombre;
    ligne.appendChild(caseHumeur);
    ligne.appendChild(caseNombre);
    corps.appendChild(ligne);
  }

  document.getElementById("total-pages").textContent = pages.length;
}

afficherPages();
afficherStatistiques();
