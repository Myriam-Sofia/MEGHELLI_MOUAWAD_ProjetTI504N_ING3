function envoyerMessage() {
  const nom = document.getElementById("nom").value;
  const email = document.getElementById("email").value;
  const sujet = document.getElementById("sujet").value;
  const texte = document.getElementById("message").value;
  const zoneMessage = document.getElementById("message-contact");

  if (nom == "" || email == "" || sujet == "" || texte == "") {
    zoneMessage.textContent = "Veuillez remplir tous les champs !";
    return;
  }

  if (email.includes("@") == false || email.includes(".") == false) {
    zoneMessage.textContent = "Cette adresse e-mail n'est pas valide.";
    return;
  }

  alert("Merci " + nom + " ! Ton message a bien été envoyé ✉️");

  document.getElementById("nom").value = "";
  document.getElementById("email").value = "";
  document.getElementById("sujet").value = "";
  document.getElementById("message").value = "";
  zoneMessage.textContent = "";
}
