const CATEGORIES = {
  drole: "😂 Drôle",
  genant: "🙈 Gênant",
  flippant: "👻 Flippant",
  emouvant: "🥹 Émouvant",
  aventure: "🧭 Aventure"
};

function lireHistoiresPerso() {
  const texte = localStorage.getItem("histoiresPerso");
  if (texte == null) {
    return [];
  }
  return JSON.parse(texte);
}

function toutesLesHistoires(histoiresDuFichier) {
  const resultat = [];
  const perso = lireHistoiresPerso();

  for (let i = perso.length - 1; i >= 0; i--) {
    resultat.push(perso[i]);
  }
  for (let i = 0; i < histoiresDuFichier.length; i++) {
    resultat.push(histoiresDuFichier[i]);
  }
  return resultat;
}

function estAimee(histoire) {
  return localStorage.getItem("like-" + histoire.id) == "oui";
}

function nombreDeCoeurs(histoire) {
  if (estAimee(histoire)) {
    return histoire.likes + 1;
  }
  return histoire.likes;
}

function afficherCoeur(bouton, histoire) {
  if (estAimee(histoire)) {
    bouton.textContent = "❤️ " + nombreDeCoeurs(histoire);
  } else {
    bouton.textContent = "🤍 " + nombreDeCoeurs(histoire);
  }
}

function creerBoutonCoeur(histoire) {
  const bouton = document.createElement("button");
  bouton.type = "button";
  bouton.className = "bouton bouton-clair";
  afficherCoeur(bouton, histoire);

  bouton.addEventListener("click", function () {
    if (estAimee(histoire)) {
      localStorage.setItem("like-" + histoire.id, "non");
    } else {
      localStorage.setItem("like-" + histoire.id, "oui");
    }
    afficherCoeur(bouton, histoire);
  });

  return bouton;
}

function creerCarte(histoire, cheminLecture) {
  const carte = document.createElement("article");
  carte.className = "carte";

  const categorie = document.createElement("span");
  categorie.className = "categorie";
  categorie.textContent = CATEGORIES[histoire.categorie];

  const titre = document.createElement("h3");
  titre.textContent = histoire.titre;

  const auteur = document.createElement("p");
  auteur.className = "petit";
  auteur.textContent = "par " + histoire.auteur + " · " + histoire.date;

  const resume = document.createElement("p");
  resume.textContent = histoire.resume;

  const boutonLire = document.createElement("button");
  boutonLire.type = "button";
  boutonLire.className = "bouton";
  boutonLire.textContent = "Lire la suite";

  boutonLire.addEventListener("click", function () {
    sessionStorage.setItem("histoireChoisie", histoire.id);
    window.location.href = cheminLecture;
  });

  carte.appendChild(categorie);
  carte.appendChild(titre);
  carte.appendChild(auteur);
  carte.appendChild(resume);
  carte.appendChild(creerBoutonCoeur(histoire));
  carte.appendChild(boutonLire);

  return carte;
}
