const phrases = [
  "Cher journal, aujourd'hui…",
  "Matcha latte en main, on écrit 🍵",
  "Tu ne vas jamais croire ce qui m'est arrivé !",
  "Ton cocon d'écriture, version slay 💅"
];
let numeroPhrase = 0;

setInterval(function () {
  numeroPhrase++;

  if (numeroPhrase == phrases.length) {
    numeroPhrase = 0;
  }
  document.getElementById("phrase").textContent = phrases[numeroPhrase];
}, 3000);

const diapos = document.getElementsByClassName("diapo");
let diapoActuelle = 0;

function afficherDiapo(numero) {
  for (let i = 0; i < diapos.length; i++) {
    diapos[i].style.display = "none";
  }
  diapos[numero].style.display = "block";
}

function diapoSuivante() {
  diapoActuelle++;
  if (diapoActuelle == diapos.length) {
    diapoActuelle = 0;
  }
  afficherDiapo(diapoActuelle);
}

function diapoPrecedente() {
  diapoActuelle--;
  if (diapoActuelle < 0) {
    diapoActuelle = diapos.length - 1;
  }
  afficherDiapo(diapoActuelle);
}

afficherDiapo(0);
setInterval(diapoSuivante, 5000);

function animerCompteur(idElement, valeurFinale) {
  const element = document.getElementById(idElement);
  let valeur = 0;

  const pas = Math.floor(valeurFinale / 30) + 1;

  const interval = setInterval(function () {
    valeur = valeur + pas;
    if (valeur >= valeurFinale) {
      valeur = valeurFinale;
      clearInterval(interval);
    }
    element.textContent = valeur;
  }, 30);
}

let nombreDePages = 0;
const journal = localStorage.getItem("journal");
if (journal != null) {
  nombreDePages = JSON.parse(journal).length;
}
animerCompteur("nb-pages", nombreDePages);

fetch("data/stories.json")
  .then(response => {
    if (!response.ok) {
      throw new Error("Fichier JSON introuvable");
    }
    return response.json();
  })
  .then(data => {
    const histoires = toutesLesHistoires(data.histoires);
    const zone = document.getElementById("dernieres-histoires");
    zone.textContent = "";

    for (let i = 0; i < 3; i++) {
      zone.appendChild(creerCarte(histoires[i], "pages/histoire.html"));
    }

    let totalCoeurs = 0;
    for (let i = 0; i < histoires.length; i++) {
      totalCoeurs = totalCoeurs + nombreDeCoeurs(histoires[i]);
    }

    animerCompteur("nb-histoires", histoires.length);
    animerCompteur("nb-coeurs", totalCoeurs);
  })
  .catch(error => {

    console.error("Problème avec le fichier JSON :", error);
    document.getElementById("dernieres-histoires").textContent =
      "Impossible de charger les histoires. Ouvre le site avec Live Server.";
  });
