let essai = 0;

function validerQuiz() {
  let score = 0;

  if (document.getElementById("q1-bonne").checked) {
    score = score + 4;
  }
  if (document.getElementById("q2-bonne").checked) {
    score = score + 4;
  }

  if (document.getElementById("q3-a").checked) {
    score = score + 2;
  }
  if (document.getElementById("q3-b").checked) {
    score = score + 2;
  }
  if (document.getElementById("q3-c").checked) {
    score = score - 2;
  }

  if (document.getElementById("q4").value == "poudlard") {
    score = score + 4;
  }

  const reponse5 = document.getElementById("q5").value.toLowerCase();
  if (reponse5.includes("storytime")) {
    score = score + 4;
  }

  if (score < 0) {
    score = 0;
  }

  essai++;
  const ligne = document.createElement("tr");
  const caseEssai = document.createElement("td");
  caseEssai.textContent = "Essai " + essai;
  const caseScore = document.createElement("td");
  caseScore.textContent = score + " / 20";
  ligne.appendChild(caseEssai);
  ligne.appendChild(caseScore);
  document.getElementById("essais").appendChild(ligne);

  const message = document.getElementById("message-quiz");
  if (score == 20) {
    message.textContent = "Score parfait ! Tu es un vrai rat de bibliothèque 📚";
  } else if (score >= 10) {
    message.textContent = "Pas mal ! Encore quelques livres et tu seras imbattable.";
  } else {
    message.textContent = "Il est temps de passer à la bibliothèque 😉";
  }

  const champs = document.getElementById("form-quiz").getElementsByTagName("input");
  for (let i = 0; i < champs.length; i++) {
    champs[i].checked = false;
    if (champs[i].type == "text") {
      champs[i].value = "";
    }
  }
  document.getElementById("q4").value = "";

  if (essai == 3) {
    document.getElementById("bouton-quiz").disabled = true;
    message.textContent = message.textContent + " (3 essais maximum, c'est terminé !)";
  }
}

const symboles = ["🌸", "🍵", "📖", "✏️", "🌙", "💌"];

let cartesRetournees = [];
let coups = 0;
let paires = 0;
let bloque = false;

function melanger(tableau) {
  for (let i = tableau.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const temporaire = tableau[i];
    tableau[i] = tableau[j];
    tableau[j] = temporaire;
  }
}

function mettreAJourCompteurs() {
  document.getElementById("coups").textContent = coups;
  document.getElementById("paires").textContent = paires;
}

function nouvellePartie() {
  cartesRetournees = [];
  coups = 0;
  paires = 0;
  bloque = false;
  mettreAJourCompteurs();

  const paquet = [];
  for (let i = 0; i < symboles.length; i++) {
    paquet.push(symboles[i]);
    paquet.push(symboles[i]);
  }
  melanger(paquet);

  const plateau = document.getElementById("plateau");
  plateau.textContent = "";
  for (let i = 0; i < paquet.length; i++) {
    plateau.appendChild(creerCarteMemory(paquet[i]));
  }
}

function creerCarteMemory(symbole) {
  const carte = document.createElement("button");
  carte.type = "button";
  carte.className = "carte-memory";
  carte.textContent = "?";
  carte.addEventListener("click", function () {
    retournerCarte(carte, symbole);
  });
  return carte;
}

function retournerCarte(carte, symbole) {

  if (bloque == true || carte.textContent != "?") {
    return;
  }

  carte.textContent = symbole;
  carte.style.backgroundColor = "#f9dce3";
  cartesRetournees.push(carte);

  if (cartesRetournees.length == 2) {
    coups++;
    comparerCartes();
    mettreAJourCompteurs();
  }
}

function comparerCartes() {
  const carte1 = cartesRetournees[0];
  const carte2 = cartesRetournees[1];

  if (carte1.textContent == carte2.textContent) {

    carte1.style.backgroundColor = "#e3ecd6";
    carte2.style.backgroundColor = "#e3ecd6";
    cartesRetournees = [];
    paires++;

    if (paires == symboles.length) {

      setTimeout(function () {
        alert("Bravo ! Tu as gagné en " + coups + " coups 🎉");
      }, 300);
    }
  } else {

    bloque = true;
    setTimeout(function () {
      carte1.textContent = "?";
      carte2.textContent = "?";
      carte1.style.backgroundColor = "#d46f8d";
      carte2.style.backgroundColor = "#d46f8d";
      cartesRetournees = [];
      bloque = false;
    }, 800);
  }
}

nouvellePartie();
